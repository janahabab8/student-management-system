module com.mycompany.finalpro {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.finalpro to javafx.fxml;
    exports com.mycompany.finalpro;
}
